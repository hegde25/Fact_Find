#!/usr/bin/python3

import nmap
import pyfiglet

scanner = nmap.PortScanner()


def SynScan(IP):
    print("Intiating SYN SCK Scan...")
    scanner.scan(IP, '1-1024' , '-v -sS')
    print("Completed SYN SCK Scan on",scanner[IP]['addresses']['ipv4'])
    print("Status: " , scanner[IP].state())
    print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
    print("--------------------------------------------------------")
    TCP = scanner[IP]['tcp']
    for key in TCP.keys():
         print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])
    #print("MAC Address:",scanner[IP]['addresses']['mac'])



def Comprehensive_Scan(IP):
    print("Starting Comprehensive Scan...")
    scanner.scan(IP, '1-1024' , '-v -sS -sV -sC -A -O')
    print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
    print("--------------------------------------------------------")
    TCP = scanner[IP]['tcp']
    for key in TCP.keys():
         print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def Intense_Scan(IP):
     print("Starting Intesive scan...")
     scanner.scan(IP, '1-1024' , '-v -T4 -A')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def Intense_Scan_Plus_UDP(IP):
     print("Starting Intsive Scan plus UDP...")
     scanner.scan(IP, '1-1024' , '-v -T4 -A -sS -sU')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def Intense_Scan_noPing(IP):
     print("Starting Intensive Scan ,No Ping ...")
     scanner.scan(IP, '1-1024' , '-v -T4 -A -Pn')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def PingScan(IP):
     print("Starting Ping Scan..")
     scanner.scan(IP, '1-1024' , '-sn')
     print(scanner[IP])
     #print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     #print("--------------------------------------------------------")
     #TCP = scanner[IP]['tcp']
     #for key in TCP.keys():
          #print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def QuickScan(IP):
     print("Starting Quick Scan")
     scanner.scan(IP, '1-1024' , '-T4 -F')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def QuickScan_plus(IP):
     print("Staring Quick Scan Plus...")
     scanner.scan(IP, '1-1024' , '-sV -T4 -O -F')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])   

def Regular_Scan(IP):
     print(" Starting Regualar Scan...")
     scanner.scan(IP, '1-1024' ,)
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])

def Quick_traceroute(IP):
     print("Starting Quick Traceroute...")
     scanner.scan(IP, '1-1024' , '-sn -traceroute')
     print("PORT\t\tSTATUS\t\tNAME\t\tREASON ")
     print("--------------------------------------------------------")
     TCP = scanner[IP]['tcp']
     for key in TCP.keys():
          print(key,"\t\t" ,TCP[key]['state'],"\t\t",TCP[key]['name'],"     ",TCP[key]['reason'])