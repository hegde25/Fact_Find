import pyfiglet
import os
import IpTracker
import PhoneTracker
import Scanner

def choice ( str ):
    if  response1=='1':
         Scanner.SynScan(ip_address)

    elif response1 == '2':
         Scanner.Comprehensive_Scan(ip_address)

    elif response1 == '3':
         Scanner.Intense_Scan(ip_address)

    elif response1 =='4':
         Scanner.Intense_Scan_Plus_UDP(ip_address)

    elif response1=='5':
         Scanner.Intense_Scan_noPing(ip_address)
    else:
         print("Plese Enter  the valid option.")

data = pyfiglet.figlet_format("fact-Finder......!?")
print(data)

print("Hello People.! :)")
print("-----------------")

response = input("""\n Please select your choice : 
                  1. Pentester 
                  2. Phone Number Tracker 
                  3. IP Tracker\n""")

if response =='1':
   ip_address = input("Enter the IP adress: ")
   type(ip_address)
   response1 = input("""\n Please enter the  type of scan you want to: 
                          1. SYN ACK scan  
                          2. Comprehensive scan
                          3. Intense Scan
                          4. Intense Scan Plus UDP
                          5. Intense Scan no ping\n """)

   choice(response1)                     
    
elif response =='2':
    PhoneTracker.Phone_number_track()

elif response=='3':
    IpTracker.tracker()

else:
    print("Please enter the valid option..:)")





