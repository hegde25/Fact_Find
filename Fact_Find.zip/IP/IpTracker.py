
import os
import requests
import json 

def tracker():

 ip = input("Enter Target IP: ")
 url = "http://ip-api.com/json/"

 response = requests.get(url+ip)
 values = json.loads(response.text)
 print("IP adress: "+ values['query'])
 print("Status: "+ values['status'])
 print("Country: "+ values['country'])
 print("Country Code: "+ values['countryCode'])
 print("Region: "+ values['region'])
 print("Region Name: "+ values['regionName'])
 print("City: "+ values['city'])
 print("ZIP: "+ values['zip'])
 print("Latitude: ", values['lat'])
 print("Longitude: ", values['lon'])
 print("Internet Service Provider (ISP): "+ values['isp'])
 print("Organization: "+ values['org'],"as",values['as'])
